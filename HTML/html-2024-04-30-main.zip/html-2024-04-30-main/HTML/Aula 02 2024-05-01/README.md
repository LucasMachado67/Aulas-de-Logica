# Lista de exercícios:

## Exercício 1
Criar página com os seguintes inputs:
- text
- email
- senha
## Exercício 2
Criar página com os seguintes inputs
- text
- tel
- number
- datetime-local
## Exercício 3
Criar página com os seguintes inputs
- text
- number
- month
- number
- week
## Exercício 4
Criar página com os seguintes inputs
- text
- date
- time
- url
## Exercício 5
Criar página com os seguintes inputs
- text
- radio (4 radios)
## Exercício 6
Criar página com os seguintes itens:
- span
- lista ordenada
## Exercício 7
Criar página com os seguintes inputs
- text
- checkbox
- color
- file
## Exercício 8
Criar página com os seguintes itens:
- span
- lista não ordenada